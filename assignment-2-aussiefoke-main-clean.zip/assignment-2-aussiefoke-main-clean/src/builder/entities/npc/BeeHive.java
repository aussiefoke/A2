package builder.entities.npc;

import builder.GameState;
import builder.entities.npc.enemies.Enemy;
import builder.ui.SpriteGallery;

import engine.EngineState;
import engine.art.sprites.SpriteGroup;

import java.util.ArrayList;

/** Spawns bees it fires at enemy's within a set range */
public class BeeHive extends Npc {

    public static final int DETECTION_DISTANCE = 350;
    private static final int BEE_COOLDOWN_TICKS = 110;
    public static final int FOOD_COST = 2;
    public static final int COIN_COST = 2;

    private static final SpriteGroup art = SpriteGallery.hive;
    private int cooldown = 0;

    public BeeHive(int x, int y) {
        super(x, y);
        this.setSprite(art.getSprite("default"));
        this.setSpeed(0);
    }

    @Override
    public void tick(EngineState state, GameState game) {
        super.tick(state);
        if (cooldown > 0) {
            cooldown -= 1;
        }
    }

    @Override
    public void interact(EngineState state, GameState game) {
        super.interact(state, game);
        Npc npc = this.checkAndSpawnBee(game.getEnemies().Birds);
        if (npc != null) {
            game.getNpcs().npcs.add(npc);
        }
    }
    public Npc checkAndSpawnBee(ArrayList<Enemy> targets) {
        if (cooldown > 0) return null;

        for (Enemy enemy : targets) {
            if (this.distanceFrom(enemy) < DETECTION_DISTANCE) {
                this.cooldown = BEE_COOLDOWN_TICKS;
                return new GuardBee(this.getX(), this.getY(), enemy);
            }
        }
        return null;
    }
}