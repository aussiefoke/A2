package builder.world;

import engine.game.ImmutablePosition;

public interface CabbageDetails extends ImmutablePosition {

}
