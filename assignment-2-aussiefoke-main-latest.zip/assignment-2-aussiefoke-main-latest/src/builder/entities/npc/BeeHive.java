package builder.entities.npc;

import builder.GameState;
import builder.entities.npc.enemies.Enemy;
import builder.ui.SpriteGallery;

import engine.EngineState;
import engine.art.sprites.SpriteGroup;
import engine.timing.RepeatingTimer;

import java.util.ArrayList;

/** Spawns bees it fires at enemy's within a set range */
public class BeeHive extends Npc {

    public static final int DETECTION_DISTANCE = 350;
    public static final int TIMER = 240;
    public static final int FOOD_COST = 2;
    public static final int COIN_COST = 2;
    private static final SpriteGroup art = SpriteGallery.hive;
    private boolean loaded = true;
    private final RepeatingTimer timer = new RepeatingTimer(TIMER);

    public BeeHive(int x, int y) {
        super(x, y);
        this.setSprite(art.getSprite("default"));
        this.setSpeed(0);
    }

    @Override
    public void tick(EngineState state, GameState game) {
        super.tick(state);
        this.timer.tick();

        if (this.timer.isFinished()) {
            this.loaded = true;
        }
    }

    @Override
    public void interact(EngineState state, GameState game) {
        super.interact(state, game);

        if (!this.loaded) {
            return;
        }
        Npc bee = trySpawnBee(game.getEnemies().Birds);
        if (bee != null) {
            game.getNpcs().npcs.add(bee);
            this.loaded = false;
        }
    }

    private Npc trySpawnBee(ArrayList<Enemy> targets) {
        for (Enemy enemy : targets) {
            if (this.distanceFrom(enemy) < DETECTION_DISTANCE) {
                return new GuardBee(this.getX(), this.getY(), enemy);
            }
        }
        return null;
    }
}
